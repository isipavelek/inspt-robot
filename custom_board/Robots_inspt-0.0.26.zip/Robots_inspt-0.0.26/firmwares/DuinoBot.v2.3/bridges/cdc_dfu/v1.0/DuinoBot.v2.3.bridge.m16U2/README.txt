DuinoBot 2.3 Firmware for Atmega32u2
------------------------------------
The files DuinoBot23-UsbDfu.hex and DuinoBot23-UsbSerial.hex are combined using mergehexs.bat. The file obtained is called DuinoBot23-Bridge.hex, that is actually the file to be programmed in the ATmega32u2 bridge in the Duinobot 2.3 board.

Fuses:
LF = 0xFF
HF = 0xD9
EF = 0xF6